<?php
/* ************************************************************************** */
/*
/*	Lian Yue
/*
/*	Url: www.lianyue.org
/*	Email: admin@lianyue.org
/*	Author: Moon
/*
/*	Created: UTC 2015-02-10 12:48:56
/*	Updated: UTC 2015-02-26 09:50:59
/*
/* ************************************************************************** */
namespace Loli\Image;
use Loli\Exception as Exception_;
class_exists('Loli\Exception') || exit;
class Exception extends Exception_{



}